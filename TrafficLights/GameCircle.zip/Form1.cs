﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Guna.UI2;

namespace TrafficLights
{
    public partial class Form1 : Form
    {
        //BackgroundWorker worker;
        Color def;
        Color forecolor1;
        Color forecolor2;
        Color forecolor3;
        int lineWidth = 2;
        int centerX = 100;
        int centerY = 120;
        int radius = 50;
        Graphics g;
        SolidBrush myBrush;
        Pen myPen;
        int num = 1;
        int sleep1;
        int sleep2;
        int sleep3;
        Thread drawingAuto;
        bool goUp = false;


        int t = 2000;
        int t_decrement = 100;
        int level = 1;
        int scoreInc = 1;
        int score = 0;
        int lifes = 3;
        int trys = 0;
        int succ_trys = 0;

        int minX = 20;
        int maxX = 500;
        int minY = 20;
        int maxY = 500;
        int x = 0;
        int y = 0;
        int r = 10;
        bool drawn = false;
        System.Timers.Timer timer1;
        public Form1()
        {
            InitializeComponent();
            forecolor1 = Color.Red;
            //forecolor2 = Color.Yellow;
            //forecolor3 = Color.Green;
            //def = Color.Gray;
            //sleep1 = Convert.ToInt32(numericUpDown1.Value);
            //sleep2 = Convert.ToInt32(numericUpDown2.Value);
            //sleep3 = Convert.ToInt32(numericUpDown3.Value);
            g = CreateGraphics();
            //myPen = new Pen(forecolor1, lineWidth);
            //myBrush = new SolidBrush(forecolor1);
            timer1 = new System.Timers.Timer
            {
                Interval = t
            };
            timer1.Elapsed += Timer1_Elapsed;
            label7.Text += level;
            label4.Text += t;
            label5.Text += score;
            label6.Text += lifes;
            timer1.Enabled = true;

            //worker = new BackgroundWorker();
            //worker.DoWork += Worker_DoWork;
            //worker.ProgressChanged += Worker_ProgressChanged;
            //worker.RunWorkerCompleted += Worker_RunWorkerCompleted;
            //worker.RunWorkerAsync();
        }

        private void Worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void Worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void Timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            g.Clear(this.BackColor);
            drawn = false;
            //timer1.Interval = t;
            //Form1_Shown(sender,e);
        }

        private void Worker_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        public static void worker_doWork()
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //if (drawingAuto != null)
            //    drawingAuto.Abort();
            //groupBox1.Enabled = false;
            //myPen = new Pen(def, lineWidth);
            //myBrush = new SolidBrush(def);
            //g.FillCircle(myBrush, centerX, centerY, radius);
            //g.DrawCircle(myPen, centerX, centerY, radius);

            //g.FillCircle(myBrush, centerX, centerY + radius * 2 + 20, radius);
            //g.DrawCircle(myPen, centerX, centerY + radius * 2 + 20, radius);

            //g.FillCircle(myBrush, centerX, centerY + radius * 4 + 40, radius);
            //g.DrawCircle(myPen, centerX, centerY + radius * 4 + 40, radius);
            //switch (num)
            //{
            //    case 1:
            //        goUp = false;
            //        myPen = new Pen(forecolor1, lineWidth);
            //        myBrush = new SolidBrush(forecolor1);
            //        g.FillCircle(myBrush, centerX, centerY, radius);
            //        g.DrawCircle(myPen, centerX, centerY, radius);
            //        break;
            //    case 2:
            //        myPen = new Pen(forecolor2, lineWidth);
            //        myBrush = new SolidBrush(forecolor2);
            //        g.FillCircle(myBrush, centerX, centerY + radius * 2 + 20, radius);
            //        g.DrawCircle(myPen, centerX, centerY + radius * 2 + 20, radius);
            //        break;
            //    case 3:
            //        goUp = true;
            //        myPen = new Pen(forecolor3, lineWidth);
            //        myBrush = new SolidBrush(forecolor3);
            //        g.FillCircle(myBrush, centerX, centerY + radius * 4 + 40, radius);
            //        g.DrawCircle(myPen, centerX, centerY + radius * 4 + 40, radius);
            //        break;
            //}
            //if (!goUp)
            //    num++;
            //else
            //    num--;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            //g.FillCircle(myBrush, centerX, centerY, radius);
            //g.DrawCircle(myPen, centerX, centerY, radius);
            //myPen = new Pen(def, lineWidth);
            //myBrush = new SolidBrush(def);
            //g.FillCircle(myBrush, centerX, centerY + radius * 2 + 20, radius);
            //g.DrawCircle(myPen, centerX, centerY + radius * 2 + 20, radius);

            //g.FillCircle(myBrush, centerX, centerY + radius * 4 + 40, radius);
            //g.DrawCircle(myPen, centerX, centerY + radius * 4 + 40, radius);
            new Thread(() =>
            {
                while (true)
                {
                    //drawn = false;


                    x = new Random().Next(minX, maxX);
                    y = new Random().Next(minY, maxY);
                    myPen = new Pen(forecolor1, lineWidth);
                    myBrush = new SolidBrush(forecolor1);
                    g.FillCircle(myBrush, x, y, r);
                    g.DrawCircle(myPen, x, y, r);
                    //timer1.Enabled = false;
                    //timer1.Enabled = true;
                    drawn = true;
                    trys += 1;
                    Thread.Sleep(t);

                }
            }).Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //if (drawingAuto != null)
            //    drawingAuto.Abort();
            //myPen = new Pen(forecolor1, lineWidth);
            //myBrush = new SolidBrush(forecolor1);
            //g.FillCircle(myBrush, centerX, centerY, radius);
            //g.DrawCircle(myPen, centerX, centerY, radius);
            //myPen = new Pen(def, lineWidth);
            //myBrush = new SolidBrush(def);
            //g.FillCircle(myBrush, centerX, centerY + radius * 2 + 20, radius);
            //g.DrawCircle(myPen, centerX, centerY + radius * 2 + 20, radius);

            //g.FillCircle(myBrush, centerX, centerY + radius * 4 + 40, radius);
            //g.DrawCircle(myPen, centerX, centerY + radius * 4 + 40, radius);
            //sleep1 = Convert.ToInt32(numericUpDown1.Value);
            //sleep2 = Convert.ToInt32(numericUpDown2.Value);
            //sleep3 = Convert.ToInt32(numericUpDown3.Value);
            //drawingAuto = new Thread(() =>
            //{
            //    while (true)
            //    {
            //        myPen = new Pen(def, lineWidth);
            //        myBrush = new SolidBrush(def);
            //        g.FillCircle(myBrush, centerX, centerY, radius);
            //        g.DrawCircle(myPen, centerX, centerY, radius);

            //        g.FillCircle(myBrush, centerX, centerY + radius * 2 + 20, radius);
            //        g.DrawCircle(myPen, centerX, centerY + radius * 2 + 20, radius);

            //        g.FillCircle(myBrush, centerX, centerY + radius * 4 + 40, radius);
            //        g.DrawCircle(myPen, centerX, centerY + radius * 4 + 40, radius);
            //        switch (num)
            //        {
            //            case 1:
            //                goUp = false;
            //                myPen = new Pen(forecolor1, lineWidth);
            //                myBrush = new SolidBrush(forecolor1);
            //                g.FillCircle(myBrush, centerX, centerY, radius);
            //                g.DrawCircle(myPen, centerX, centerY, radius);
            //                Thread.Sleep(sleep1);
            //                break;
            //            case 2:
            //                myPen = new Pen(forecolor2, lineWidth);
            //                myBrush = new SolidBrush(forecolor2);
            //                g.FillCircle(myBrush, centerX, centerY + radius * 2 + 20, radius);
            //                g.DrawCircle(myPen, centerX, centerY + radius * 2 + 20, radius);
            //                Thread.Sleep(sleep2);
            //                break;
            //            case 3:
            //                goUp = true;
            //                myPen = new Pen(forecolor3, lineWidth);
            //                myBrush = new SolidBrush(forecolor3);
            //                g.FillCircle(myBrush, centerX, centerY + radius * 4 + 40, radius);
            //                g.DrawCircle(myPen, centerX, centerY + radius * 4 + 40, radius);
            //                Thread.Sleep(sleep3);
            //                break;
            //        }
            //        if (!goUp)
            //            num++;
            //        else
            //            num--;
            //    }
            //});
            //drawingAuto.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //groupBox1.Enabled = true;
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (drawn)
            {
                //x = x;
                //y = y;
                //int MX = MousePosition.X - this.Location.X - 8;
                //int MY = MousePosition.Y - this.Location.Y - 30;
                //if (1 && 1)
                //{
                    if (lifes - trys > 0)
                    {
                        succ_trys += 1;
                        score += scoreInc;
                        t -= t_decrement;
                    }
                //}
            }
            label7.Text = $"Level: {level}";
            label4.Text = $"Time(ms): {t}";
            label5.Text = $"Score(N): {score}";
            label6.Text = $"Lifes(P): {lifes}";
        }
    }
}
